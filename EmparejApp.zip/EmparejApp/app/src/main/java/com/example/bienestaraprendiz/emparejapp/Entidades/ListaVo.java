package com.example.bienestaraprendiz.emparejapp.Entidades;


//en este clase realizamos la lista de los cinco mejores puntajes en cada unos de los diferentes niveles
//con su respectivo puntaje y tiempo, esta la utilizamos para el salon de la fama o la opcion scores
public class ListaVo {
    String player1,player2,player3,player4,player5,puntaje1,puntaje2,puntaje3,puntaje4,puntaje5,tiempo1,tiempo2,tiempo3,tiempo4,tiempo5;

    public ListaVo(String player1, String player2, String player3, String player4, String player5, String puntaje1, String puntaje2, String puntaje3, String puntaje4, String puntaje5, String tiempo1, String tiempo2, String tiempo3, String tiempo4, String tiempo5) {
        this.player1 = player1;
        this.player2 = player2;
        this.player3 = player3;
        this.player4 = player4;
        this.player5 = player5;
        this.puntaje1 = puntaje1;
        this.puntaje2 = puntaje2;
        this.puntaje3 = puntaje3;
        this.puntaje4 = puntaje4;
        this.puntaje5 = puntaje5;
        this.tiempo1 = tiempo1;
        this.tiempo2 = tiempo2;
        this.tiempo3 = tiempo3;
        this.tiempo4 = tiempo4;
        this.tiempo5 = tiempo5;
    }
//aqui esta los metodos get y set para cada uno de ellos
    public String getPlayer1() {
        return player1;
    }

    public void setPlayer1(String player1) {
        this.player1 = player1;
    }

    public String getPlayer2() {
        return player2;
    }

    public void setPlayer2(String player2) {
        this.player2 = player2;
    }

    public String getPlayer3() {
        return player3;
    }

    public void setPlayer3(String player3) {
        this.player3 = player3;
    }

    public String getPlayer4() {
        return player4;
    }

    public void setPlayer4(String player4) {
        this.player4 = player4;
    }

    public String getPlayer5() {
        return player5;
    }

    public void setPlayer5(String player5) {
        this.player5 = player5;
    }

    public String getPuntaje1() {
        return puntaje1;
    }

    public void setPuntaje1(String puntaje1) {
        this.puntaje1 = puntaje1;
    }

    public String getPuntaje2() {
        return puntaje2;
    }

    public void setPuntaje2(String puntaje2) {
        this.puntaje2 = puntaje2;
    }

    public String getPuntaje3() {
        return puntaje3;
    }

    public void setPuntaje3(String puntaje3) {
        this.puntaje3 = puntaje3;
    }

    public String getPuntaje4() {
        return puntaje4;
    }

    public void setPuntaje4(String puntaje4) {
        this.puntaje4 = puntaje4;
    }

    public String getPuntaje5() {
        return puntaje5;
    }

    public void setPuntaje5(String puntaje5) {
        this.puntaje5 = puntaje5;
    }

    public String getTiempo1() {
        return tiempo1;
    }

    public void setTiempo1(String tiempo1) {
        this.tiempo1 = tiempo1;
    }

    public String getTiempo2() {
        return tiempo2;
    }

    public void setTiempo2(String tiempo2) {
        this.tiempo2 = tiempo2;
    }

    public String getTiempo3() {
        return tiempo3;
    }

    public void setTiempo3(String tiempo3) {
        this.tiempo3 = tiempo3;
    }

    public String getTiempo4() {
        return tiempo4;
    }

    public void setTiempo4(String tiempo4) {
        this.tiempo4 = tiempo4;
    }

    public String getTiempo5() {
        return tiempo5;
    }

    public void setTiempo5(String tiempo5) {
        this.tiempo5 = tiempo5;
    }
}
